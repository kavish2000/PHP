<?php

include ("dbconnection.php");

    $q = "select * from user";
    $query = mysqli_query($conn,$q);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Display</title>
  </head>
<body>
    <br><br>

	<table >
	<tr>
	<th><b><u>ID</u></b></th>
	<th><b><u>NAME</u></b></th>
	<th><b><u>EMAIL</u></b></th>
	<th><b><u>PHONE</u></b></th>
	<th><b><u>CREATED DATE</u></b></th>
    <th><b><u>UPADTED DATE</u></b></th>
    <th>Delete</th>
     <th>Update</th>

               
	</tr>
	
	<?php
		$sql8="select * from user";
	  $result = $conn1->query($sql8);
		while($row=$result->fetch_array())
		{ 
		$id = $row['id'];
        echo "<tr>";
		echo "<td>" .$row['id']. "</td>";
	    echo "<td>" .$row['username']. "</td>";
		echo "<td>" .$row['email']. "</td>";
		echo "<td>" .$row['phoneno']. "</td>";
		echo "<td>" .$row['create_date']. "</td>";
        echo "<td>" .$row['update_date']. "</td>";
        $c="delete.php?id=$id";
        echo "<td><a  href=$c >delete</a></td>";
        $t="update_form.php?id=$id";
        echo "<td><a  href=$t >update</a></td>";
        
       
        echo "</tr>";
        
		}
    
        
	?>
                    
</body>
</html>